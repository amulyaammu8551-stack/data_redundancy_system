from .classifier import classify, UNIQUE_VERIFIED, REDUNDANT, FALSE_POSITIVE


def process(db, records: list, verbose: bool = True) -> dict:
    """Classify each record; append only UNIQUE_VERIFIED ones."""
    stats = {UNIQUE_VERIFIED: 0, REDUNDANT: 0, FALSE_POSITIVE: 0}
    for rec in records:
        res, n, fp = classify(db, rec)
        if res.category == UNIQUE_VERIFIED:
            try:
                db.insert(n, fp)
            except db.IntegrityError as e:  # safety net for race conditions
                res.category, res.reason = REDUNDANT, f"db constraint: {e}"
        stats[res.category] += 1
        if res.category != UNIQUE_VERIFIED:
            db.log_rejected(rec, res.category, res.reason)
        if verbose:
            tag = "ADDED" if res.category == UNIQUE_VERIFIED else res.category
            print(f"[{tag}] {rec.get('name')!r} -> {res.reason}")
    return stats
