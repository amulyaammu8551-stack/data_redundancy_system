"""
SQLite stands in for the cloud database. To use PostgreSQL / MySQL / Firebase /
Supabase, re-implement this class with the same methods; nothing else changes.
"""
import json
import sqlite3
from datetime import datetime, timezone

from .normalizer import blocking_key


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    IntegrityError = sqlite3.IntegrityError

    def __init__(self, path=":memory:"):
        self.con = sqlite3.connect(path)
        self.con.row_factory = sqlite3.Row
        self.con.executescript("""
            CREATE TABLE IF NOT EXISTS records(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT, email TEXT, phone TEXT, city TEXT,
                fingerprint TEXT UNIQUE NOT NULL,
                block_key TEXT,
                created_at TEXT
            );
            CREATE UNIQUE INDEX IF NOT EXISTS ux_email ON records(email);
            CREATE UNIQUE INDEX IF NOT EXISTS ux_phone ON records(phone);
            CREATE INDEX IF NOT EXISTS ix_block ON records(block_key);

            CREATE TABLE IF NOT EXISTS rejected(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payload TEXT, category TEXT, reason TEXT, created_at TEXT
            );
        """)

    def find_by_fingerprint(self, fp):
        return self.con.execute("SELECT * FROM records WHERE fingerprint=?", (fp,)).fetchone()

    def find_by_email_or_phone(self, email, phone):
        return self.con.execute(
            "SELECT * FROM records WHERE email=? OR phone=?", (email, phone)).fetchone()

    def candidates(self, key):
        return self.con.execute("SELECT * FROM records WHERE block_key=?", (key,)).fetchall()

    def insert(self, n, fp):
        self.con.execute(
            "INSERT INTO records(name,email,phone,city,fingerprint,block_key,created_at)"
            " VALUES(?,?,?,?,?,?,?)",
            (n["name"], n["email"], n["phone"], n["city"], fp, blocking_key(n), now()))
        self.con.commit()

    def log_rejected(self, rec, category, reason):
        self.con.execute(
            "INSERT INTO rejected(payload,category,reason,created_at) VALUES(?,?,?,?)",
            (json.dumps(rec), category, reason, now()))
        self.con.commit()

    def count(self):
        return self.con.execute("SELECT COUNT(*) FROM records").fetchone()[0]

    def rejected(self):
        return self.con.execute("SELECT category, reason FROM rejected").fetchall()

    def records(self):
        return self.con.execute(
            "SELECT id, name, email, phone, city FROM records ORDER BY id").fetchall()

    def rejected_full(self):
        return self.con.execute(
            "SELECT payload, category, reason FROM rejected ORDER BY id DESC").fetchall()

    def reset(self):
        self.con.execute("DELETE FROM records")
        self.con.execute("DELETE FROM rejected")
        self.con.commit()
