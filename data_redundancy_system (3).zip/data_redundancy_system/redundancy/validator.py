import re

EMAIL_RE = re.compile(r"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$")


def validate(n: dict) -> list:
    """Return a list of problems. Any problem => FALSE_POSITIVE."""
    errors = []
    if len(n["name"]) < 2 or not re.fullmatch(r"[a-z .'-]+", n["name"]):
        errors.append("invalid name")
    if not EMAIL_RE.match(n["email"]):
        errors.append("invalid email")
    if len(n["phone"]) != 10:
        errors.append("invalid phone (need 10 digits)")
    if not n["city"]:
        errors.append("missing city")
    return errors
