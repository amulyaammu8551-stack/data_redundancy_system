import hashlib
import re


def normalize(rec: dict) -> dict:
    """Canonical form so ' John  DOE' and 'john doe' compare equal."""
    return {
        "name": re.sub(r"\s+", " ", str(rec.get("name", "")).strip().lower()),
        "email": str(rec.get("email", "")).strip().lower(),
        "phone": re.sub(r"\D", "", str(rec.get("phone", "")))[-10:],
        "city": re.sub(r"\s+", " ", str(rec.get("city", "")).strip().lower()),
    }


def fingerprint(n: dict) -> str:
    raw = "|".join([n["name"], n["email"], n["phone"], n["city"]])
    return hashlib.sha256(raw.encode()).hexdigest()


def blocking_key(n: dict) -> str:
    """Cheap key so fuzzy matching only runs on a small candidate set."""
    return n["name"][:3]
