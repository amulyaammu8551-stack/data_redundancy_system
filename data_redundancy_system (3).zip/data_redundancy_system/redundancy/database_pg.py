"""
Cloud PostgreSQL backend (Supabase, Neon, Render, AWS RDS, ...).
Same methods as the SQLite Database class, so nothing else changes.

    pip install psycopg2-binary
    set DATABASE_URL=postgresql://user:password@host:5432/dbname   (PowerShell: $env:DATABASE_URL="...")
    python app.py
"""
import json

from .database import now
from .normalizer import blocking_key


class PostgresDatabase:
    def __init__(self, url):
        import psycopg2
        import psycopg2.extras
        self.IntegrityError = psycopg2.IntegrityError
        self.con = psycopg2.connect(url)
        self.con.autocommit = True
        self._cursor_factory = psycopg2.extras.RealDictCursor
        self._run("""
            CREATE TABLE IF NOT EXISTS records(
                id SERIAL PRIMARY KEY,
                name TEXT, email TEXT UNIQUE, phone TEXT UNIQUE, city TEXT,
                fingerprint TEXT UNIQUE NOT NULL,
                block_key TEXT,
                created_at TEXT
            )""")
        self._run("CREATE INDEX IF NOT EXISTS ix_block ON records(block_key)")
        self._run("""
            CREATE TABLE IF NOT EXISTS rejected(
                id SERIAL PRIMARY KEY,
                payload TEXT, category TEXT, reason TEXT, created_at TEXT
            )""")

    def _run(self, sql, params=(), fetch=None):
        with self.con.cursor(cursor_factory=self._cursor_factory) as cur:
            cur.execute(sql, params)
            if fetch == "one":
                return cur.fetchone()
            if fetch == "all":
                return cur.fetchall()

    def find_by_fingerprint(self, fp):
        return self._run("SELECT * FROM records WHERE fingerprint=%s", (fp,), "one")

    def find_by_email_or_phone(self, email, phone):
        return self._run("SELECT * FROM records WHERE email=%s OR phone=%s LIMIT 1",
                         (email, phone), "one")

    def candidates(self, key):
        return self._run("SELECT * FROM records WHERE block_key=%s", (key,), "all")

    def insert(self, n, fp):
        self._run(
            "INSERT INTO records(name,email,phone,city,fingerprint,block_key,created_at)"
            " VALUES(%s,%s,%s,%s,%s,%s,%s)",
            (n["name"], n["email"], n["phone"], n["city"], fp, blocking_key(n), now()))

    def log_rejected(self, rec, category, reason):
        self._run("INSERT INTO rejected(payload,category,reason,created_at) VALUES(%s,%s,%s,%s)",
                  (json.dumps(rec), category, reason, now()))

    def count(self):
        return self._run("SELECT COUNT(*) AS c FROM records", fetch="one")["c"]

    def rejected(self):
        return self._run("SELECT category, reason FROM rejected", fetch="all")

    def records(self):
        return self._run("SELECT id, name, email, phone, city FROM records ORDER BY id", fetch="all")

    def rejected_full(self):
        return self._run("SELECT payload, category, reason FROM rejected ORDER BY id DESC", fetch="all")

    def reset(self):
        self._run("DELETE FROM records")
        self._run("DELETE FROM rejected")
