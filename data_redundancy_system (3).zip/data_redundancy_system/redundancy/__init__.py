from .pipeline import process
from .database import Database
from .classifier import classify, UNIQUE_VERIFIED, REDUNDANT, FALSE_POSITIVE


def connect(url=None, sqlite_path="cloud_copy.db"):
    """Cloud PostgreSQL if a URL is given, otherwise a local SQLite file."""
    if url:
        from .database_pg import PostgresDatabase
        return PostgresDatabase(url)
    return Database(sqlite_path)
