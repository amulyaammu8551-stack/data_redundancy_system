from dataclasses import dataclass
from difflib import SequenceMatcher

from .normalizer import normalize, fingerprint, blocking_key
from .validator import validate

UNIQUE_VERIFIED = "UNIQUE_VERIFIED"
REDUNDANT = "REDUNDANT"
FALSE_POSITIVE = "FALSE_POSITIVE"

NEAR_DUP_THRESHOLD = 0.90


@dataclass
class Result:
    category: str
    reason: str


def similar(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def classify(db, rec: dict):
    """Returns (Result, normalized_record, fingerprint)."""
    n = normalize(rec)

    # 1. False positive: fails validation
    errors = validate(n)
    if errors:
        return Result(FALSE_POSITIVE, "; ".join(errors)), n, None

    fp = fingerprint(n)

    # 2. Exact duplicate
    if db.find_by_fingerprint(fp):
        return Result(REDUNDANT, "exact duplicate"), n, fp

    # 3. Same email or phone already registered
    hit = db.find_by_email_or_phone(n["email"], n["phone"])
    if hit:
        return Result(REDUNDANT, f"email/phone already exists (id={hit['id']})"), n, fp

    # 4. Near duplicate: similar name in the same city
    for row in db.candidates(blocking_key(n)):
        score = similar(n["name"], row["name"])
        if score >= NEAR_DUP_THRESHOLD and n["city"] == row["city"]:
            return Result(REDUNDANT, f"near duplicate of id={row['id']} (score={score:.2f})"), n, fp

    return Result(UNIQUE_VERIFIED, "new, valid and unique"), n, fp
