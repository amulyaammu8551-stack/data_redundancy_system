"""
Web interface for the Data Redundancy Removal System.
Uses only the Python standard library (no pip install needed).

Run:   python app.py
Open:  http://127.0.0.1:8000
"""
import html
import json
import os
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse, quote

from redundancy import connect, process, classify, UNIQUE_VERIFIED, REDUNDANT, FALSE_POSITIVE

HOST, PORT = "127.0.0.1", 8000
DATABASE_URL = os.environ.get("DATABASE_URL")  # set this to use a cloud PostgreSQL DB
db = connect(DATABASE_URL)

SAMPLE = [
    {"name": "Amit Sharma", "email": "amit@mail.com", "phone": "9876543210", "city": "Bengaluru"},
    {"name": "Priya Nair", "email": "priya@mail.com", "phone": "9123456780", "city": "Chennai"},
    {"name": "  amit   SHARMA ", "email": "AMIT@mail.com", "phone": "9876543210", "city": "bengaluru"},
    {"name": "Amit Sharmaa", "email": "amit.s@mail.com", "phone": "9000000001", "city": "Bengaluru"},
    {"name": "Priya Nair", "email": "priya@mail.com", "phone": "9999999999", "city": "Mumbai"},
    {"name": "Ravi Kumar", "email": "ravi@@mail", "phone": "123", "city": ""},
    {"name": "Sneha Rao", "email": "sneha@mail.com", "phone": "9345678901", "city": "Hyderabad"},
]

CSS = """
body{font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;margin:0;color:#222}
header{background:#1f3a5f;color:#fff;padding:18px 32px}
header h1{margin:0;font-size:22px} header p{margin:4px 0 0;opacity:.8;font-size:14px}
main{max-width:1000px;margin:24px auto;padding:0 16px}
.card{background:#fff;border-radius:10px;padding:20px;margin-bottom:20px;box-shadow:0 1px 4px rgba(0,0,0,.1)}
h2{margin-top:0;font-size:17px}
form.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
input{padding:9px;border:1px solid #bbb;border-radius:6px;font-size:14px}
button{padding:9px 16px;border:0;border-radius:6px;background:#1f3a5f;color:#fff;cursor:pointer;font-size:14px}
button.alt{background:#2e7d32} button.danger{background:#c62828}
.actions{display:flex;gap:10px;margin-top:10px}
table{width:100%;border-collapse:collapse;font-size:14px}
th,td{padding:8px;border-bottom:1px solid #e3e3e3;text-align:left}
th{background:#f0f3f8}
.msg{padding:12px 16px;border-radius:8px;margin-bottom:20px;font-weight:600}
.ok{background:#e6f4ea;color:#1b5e20}.dup{background:#fff4e0;color:#8a5200}.bad{background:#fdecea;color:#b71c1c}
.tag{padding:2px 8px;border-radius:10px;font-size:12px;font-weight:600}
.REDUNDANT{background:#fff4e0;color:#8a5200}.FALSE_POSITIVE{background:#fdecea;color:#b71c1c}
"""


def page(msg="", kind=""):
    rows = "".join(
        f"<tr><td>{r['id']}</td><td>{html.escape(r['name'])}</td><td>{html.escape(r['email'])}</td>"
        f"<td>{html.escape(r['phone'])}</td><td>{html.escape(r['city'])}</td></tr>"
        for r in db.records()) or "<tr><td colspan=5>No records yet</td></tr>"

    rej = ""
    for r in db.rejected_full():
        p = json.loads(r["payload"])
        rej += (f"<tr><td>{html.escape(str(p.get('name','')))}</td>"
                f"<td>{html.escape(str(p.get('email','')))}</td>"
                f"<td><span class='tag {r['category']}'>{r['category']}</span></td>"
                f"<td>{html.escape(r['reason'])}</td></tr>")
    rej = rej or "<tr><td colspan=4>Nothing rejected yet</td></tr>"

    banner = f"<div class='msg {html.escape(kind)}'>{html.escape(msg)}</div>" if msg else ""
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>Data Redundancy Removal System</title><style>{CSS}</style></head><body>
<header><h1>Data Redundancy Removal System</h1>
<p>Classifies data as unique, redundant or false positive, and stores only unique, verified entries.</p></header>
<main>{banner}
<div class="card"><h2>Add a record</h2>
<form class="grid" method="post" action="/add">
<input name="name" placeholder="Name" required><input name="email" placeholder="Email">
<input name="phone" placeholder="Phone (10 digits)"><input name="city" placeholder="City">
<div class="actions" style="grid-column:1/-1"><button type="submit">Check &amp; Add</button></div></form>
<div class="actions">
<form method="post" action="/sample"><button class="alt">Load sample data</button></form>
<form method="post" action="/reset"><button class="danger">Reset database</button></form></div></div>
<div class="card"><h2>Database (unique &amp; verified) &mdash; {len(db.records())} records</h2>
<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th></tr>{rows}</table></div>
<div class="card"><h2>Rejected (redundant / false positive)</h2>
<table><tr><th>Name</th><th>Email</th><th>Category</th><th>Reason</th></tr>{rej}</table></div>
</main></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def _send(self, body, code=200):
        data = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _redirect(self, msg, kind):
        self.send_response(303)
        self.send_header("Location", f"/?msg={quote(msg)}&kind={kind}")
        self.end_headers()

    def do_GET(self):
        q = parse_qs(urlparse(self.path).query)
        self._send(page(q.get("msg", [""])[0], q.get("kind", [""])[0]))

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        form = {k: v[0] for k, v in parse_qs(self.rfile.read(length).decode()).items()}
        route = urlparse(self.path).path

        if route == "/add":
            res, _, _ = classify(db, form)
            process(db, [form], verbose=False)
            kind = {UNIQUE_VERIFIED: "ok", REDUNDANT: "dup", FALSE_POSITIVE: "bad"}[res.category]
            self._redirect(f"{res.category}: {res.reason}", kind)
        elif route == "/sample":
            s = process(db, SAMPLE, verbose=False)
            self._redirect(f"Sample processed: {s[UNIQUE_VERIFIED]} added, "
                           f"{s[REDUNDANT]} redundant, {s[FALSE_POSITIVE]} false positive", "ok")
        elif route == "/reset":
            db.reset()
            self._redirect("Database cleared", "ok")
        else:
            self._send("Not found", 404)

    def log_message(self, *args):
        pass  # keep the terminal clean


if __name__ == "__main__":
    url = f"http://{HOST}:{PORT}"
    print("=" * 50)
    print(" Data Redundancy Removal System is running")
    print(" Database:", "cloud PostgreSQL" if DATABASE_URL else "local SQLite (cloud_copy.db)")
    print(f" Open this link:  {url}")
    print(" Press Ctrl+C to stop")
    print("=" * 50)
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        HTTPServer((HOST, PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
