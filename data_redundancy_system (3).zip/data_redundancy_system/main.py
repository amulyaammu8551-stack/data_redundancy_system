from redundancy import Database, process

if __name__ == "__main__":
    db = Database()  # Database("cloud_copy.db") for a persistent file

    batch_1 = [
        {"name": "Amit Sharma", "email": "amit@mail.com", "phone": "+91 98765 43210", "city": "Bengaluru"},
        {"name": "Priya Nair", "email": "priya@mail.com", "phone": "9123456780", "city": "Chennai"},
    ]
    batch_2 = [
        {"name": "  amit   SHARMA ", "email": "AMIT@mail.com", "phone": "9876543210", "city": "bengaluru"},
        {"name": "Amit Sharmaa", "email": "amit.s@mail.com", "phone": "9000000001", "city": "Bengaluru"},
        {"name": "Priya Nair", "email": "priya@mail.com", "phone": "9999999999", "city": "Mumbai"},
        {"name": "Ravi Kumar", "email": "ravi@@mail", "phone": "123", "city": ""},
        {"name": "Sneha Rao", "email": "sneha@mail.com", "phone": "9345678901", "city": "Hyderabad"},
    ]

    print("--- Batch 1 ---");  print(process(db, batch_1))
    print("\n--- Batch 2 ---"); print(process(db, batch_2))
    print(f"\nRecords in database: {db.count()}")
    print("Rejected log:")
    for r in db.rejected():
        print("  ", r["category"], "|", r["reason"])
