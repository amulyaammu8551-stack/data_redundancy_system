import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from redundancy import Database, process, UNIQUE_VERIFIED, REDUNDANT, FALSE_POSITIVE

BASE = {"name": "Amit Sharma", "email": "amit@mail.com", "phone": "9876543210", "city": "Bengaluru"}


def fresh():
    db = Database()
    process(db, [BASE], verbose=False)
    return db


def test_unique_record_is_added():
    db = Database()
    s = process(db, [BASE], verbose=False)
    assert s[UNIQUE_VERIFIED] == 1 and db.count() == 1


def test_exact_duplicate_rejected():
    db = fresh()
    s = process(db, [dict(BASE, name=" AMIT  sharma ")], verbose=False)
    assert s[REDUNDANT] == 1 and db.count() == 1


def test_same_email_rejected():
    db = fresh()
    s = process(db, [dict(BASE, name="Someone Else", phone="9000000000")], verbose=False)
    assert s[REDUNDANT] == 1 and db.count() == 1


def test_near_duplicate_rejected():
    db = fresh()
    rec = dict(BASE, name="Amit Sharmaa", email="x@mail.com", phone="9000000001")
    s = process(db, [rec], verbose=False)
    assert s[REDUNDANT] == 1 and db.count() == 1


def test_false_positive_rejected():
    db = Database()
    s = process(db, [{"name": "R", "email": "bad", "phone": "1", "city": ""}], verbose=False)
    assert s[FALSE_POSITIVE] == 1 and db.count() == 0


def test_rejects_are_logged():
    db = fresh()
    process(db, [BASE], verbose=False)
    assert len(db.rejected()) == 1
