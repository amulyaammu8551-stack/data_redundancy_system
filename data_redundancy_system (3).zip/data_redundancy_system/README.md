# Data Redundancy Removal System

Task 1: identify and classify data as **redundant** or **false positive**, validate new
data against existing data, and append only **unique and verified** entries to the
(cloud) database.

## Structure
```
data_redundancy_system/
├── app.py                   # web interface (link: http://127.0.0.1:8000)
├── main.py                  # command-line demo
├── requirements.txt
├── redundancy/
│   ├── normalizer.py        # canonical form, SHA-256 fingerprint, blocking key
│   ├── validator.py         # rules that flag FALSE_POSITIVE data
│   ├── database.py          # local SQLite backend
│   ├── database_pg.py       # cloud PostgreSQL backend
│   ├── classifier.py        # UNIQUE_VERIFIED / REDUNDANT / FALSE_POSITIVE
│   └── pipeline.py          # processes a batch, appends only unique + verified
└── tests/test_pipeline.py
```

## Run
```
python app.py      # web interface at http://127.0.0.1:8000
python main.py     # command-line demo
pip install pytest && pytest -q
```

## How it works
1. **Normalize** each record (case, spaces, phone digits).
2. **Validate**: invalid name/email/phone or missing city => `FALSE_POSITIVE`.
3. **Check against existing data**: exact fingerprint match, same email/phone, then a
   fuzzy name match (>= 0.90) in the same city => `REDUNDANT`.
4. **Append** only `UNIQUE_VERIFIED` records. `UNIQUE` constraints on fingerprint,
   email and phone are a second line of defence in the database itself.
5. Rejected records go to a `rejected` audit table with category and reason.

## Efficiency
Indexes on email, phone and a blocking key mean fuzzy matching only compares against
a small candidate set, not the entire table.

## Using a real cloud database
Re-implement the methods of `redundancy/database.py` for PostgreSQL / MySQL /
Firebase / Supabase. The classifier and pipeline need no changes.

## Cloud database (PostgreSQL: Supabase / Neon / Render / AWS RDS)
```
pip install psycopg2-binary
# PowerShell:
$env:DATABASE_URL="postgresql://user:password@host:5432/dbname"
python app.py
```
If `DATABASE_URL` is not set, the app uses a local SQLite file (`cloud_copy.db`).
The terminal prints which database is in use.
